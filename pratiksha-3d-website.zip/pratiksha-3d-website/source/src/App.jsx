import React, { useCallback, useEffect, useState } from 'react'
import Scene from './gl/Scene.jsx'
import Overlay from './ui/Overlay.jsx'

function hasWebGL() {
  try {
    const c = document.createElement('canvas')
    return !!(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl')))
  } catch (e) {
    return false
  }
}

function Preloader({ done }) {
  return (
    <div className="pre" data-done={done} aria-hidden={done}>
      <b>Pratiksha Enterprises</b>
      <svg viewBox="0 0 300 24" fill="none" aria-hidden="true">
        <path
          d="M4 16c18-9 36 6 54-2s36-9 54-1 36 10 54 2 36-8 54-1 36 7 54 0"
          stroke="#d4511c"
          strokeWidth="3"
          strokeLinecap="round"
        />
      </svg>
      <em>loading</em>
    </div>
  )
}

export default function App() {
  const [ready, setReady] = useState(false)
  const [narrow, setNarrow] = useState(
    typeof window !== 'undefined' ? window.innerWidth < 860 : false
  )
  const [reduced] = useState(() =>
    typeof window !== 'undefined'
      ? window.matchMedia('(prefers-reduced-motion: reduce)').matches
      : false
  )
  const [gl] = useState(() => (typeof window !== 'undefined' ? hasWebGL() : false))
  const [sectionIdx, setSectionIdx] = useState(0)

  // The card faces are drawn with Syne and Kalam, so textures must wait for the
  // webfonts — otherwise every card bakes a fallback face into its texture.
  useEffect(() => {
    let alive = true
    const go = () => alive && setReady(true)
    if (!document.fonts) return go()
    Promise.race([
      Promise.all([
        document.fonts.load('800 30px Syne'),
        document.fonts.load('700 20px Kalam'),
        document.fonts.load('400 17px Kalam'),
        document.fonts.ready,
      ]),
      new Promise((r) => setTimeout(r, 2500)), // never hold the page hostage
    ]).then(go, go)
    return () => {
      alive = false
    }
  }, [])

  useEffect(() => {
    const onResize = () => setNarrow(window.innerWidth < 860)
    window.addEventListener('resize', onResize, { passive: true })
    return () => window.removeEventListener('resize', onResize)
  }, [])

  // Fade the canvas out once the flat sheets take over.
  useEffect(() => {
    if (!gl) return
    let raf = 0
    const tick = () => {
      raf = 0
      const stage = document.getElementById('stage')
      if (!stage) return
      // Fully opaque until the stage bottom passes the viewport bottom (d = 0),
      // then fade across the next 60% of a screen. Fading *before* d reaches 0
      // would hide the final scene while it is still the one being looked at.
      const end = stage.offsetTop + stage.offsetHeight
      const d = end - (window.scrollY + window.innerHeight)
      const fade = window.innerHeight * 0.6
      const o = Math.max(0, Math.min(1, (d + fade) / fade))
      document.documentElement.style.setProperty('--gl-opacity', o.toFixed(3))
      // once the paper sheets are behind the header it needs its own ground
      document.documentElement.dataset.past = o < 0.985 ? 'true' : 'false'
    }
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(tick)
    }
    tick()
    window.addEventListener('scroll', onScroll, { passive: true })
    window.addEventListener('resize', onScroll, { passive: true })
    return () => {
      window.removeEventListener('scroll', onScroll)
      window.removeEventListener('resize', onScroll)
      if (raf) cancelAnimationFrame(raf)
    }
  }, [gl])

  const onProgress = useCallback((p) => {
    const i = Math.max(0, Math.min(4, Math.round(p * 4)))
    setSectionIdx((prev) => (prev === i ? prev : i))
  }, [])

  const jump = useCallback((i) => {
    const stage = document.getElementById('stage')
    if (!stage) return
    const span = stage.offsetHeight - window.innerHeight
    window.scrollTo({
      top: stage.offsetTop + (span * i) / 4,
      behavior: reduced ? 'auto' : 'smooth',
    })
  }, [reduced])

  return (
    <div className={gl ? '' : 'nogl'}>
      {gl && ready && (
        <div className="gl-wrap" aria-hidden="true">
          <Scene narrow={narrow} reduced={reduced} onProgress={onProgress} />
        </div>
      )}
      <div className="grain" aria-hidden="true" />
      <div className="fibre" aria-hidden="true" />
      <div className="vignette" aria-hidden="true" />
      <Overlay progress={sectionIdx / 4} onJump={jump} />
      <Preloader done={ready} />
    </div>
  )
}
