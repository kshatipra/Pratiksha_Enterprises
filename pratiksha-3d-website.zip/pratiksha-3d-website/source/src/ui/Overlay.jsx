import React, { useEffect, useRef } from 'react'
import { SHOP, SERVICES, STEPS } from '../data.js'

function useReveal() {
  const ref = useRef(null)
  useEffect(() => {
    const nodes = ref.current?.querySelectorAll('.reveal')
    if (!nodes?.length) return
    if (!('IntersectionObserver' in window)) {
      nodes.forEach((n) => n.classList.add('on'))
      return
    }
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add('on')),
      { threshold: 0.18, rootMargin: '0px 0px -6% 0px' }
    )
    nodes.forEach((n) => io.observe(n))
    return () => io.disconnect()
  }, [])
  return ref
}

const waHref = `https://wa.me/${SHOP.whatsapp}?text=${encodeURIComponent(
  'Hello Pratiksha Enterprises, I need help with '
)}`

const IconPhone = (p) => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="M21.5 16.9v2.9a2 2 0 0 1-2.2 2 19.5 19.5 0 0 1-8.5-3 19.2 19.2 0 0 1-5.9-5.9 19.5 19.5 0 0 1-3-8.6 2 2 0 0 1 2-2.2h2.9a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L7.7 10a15.4 15.4 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.6 2Z" />
  </svg>
)
const IconWa = (p) => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" {...p}>
    <path d="M12.04 2C6.6 2 2.2 6.4 2.2 11.84c0 1.74.46 3.44 1.32 4.94L2 22l5.36-1.4a9.8 9.8 0 0 0 4.68 1.2c5.43 0 9.84-4.4 9.84-9.84 0-2.63-1.02-5.1-2.88-6.96A9.78 9.78 0 0 0 12.04 2Zm0 18a8.2 8.2 0 0 1-4.16-1.14l-.3-.18-3.1.82.83-3.03-.2-.31a8.15 8.15 0 0 1-1.25-4.33c0-4.5 3.67-8.17 8.18-8.17a8.13 8.13 0 0 1 8.17 8.18c0 4.5-3.67 8.16-8.17 8.16Zm4.49-6.12c-.25-.12-1.46-.72-1.68-.8-.23-.09-.39-.13-.56.12s-.64.8-.78.97c-.15.16-.29.18-.53.06a6.7 6.7 0 0 1-1.97-1.21 7.4 7.4 0 0 1-1.37-1.7c-.14-.25-.01-.38.11-.5.11-.11.25-.29.37-.44.12-.15.16-.25.25-.42.08-.16.04-.31-.02-.43-.06-.13-.56-1.34-.76-1.84-.2-.48-.4-.41-.56-.42h-.47c-.16 0-.43.06-.65.31-.23.25-.86.84-.86 2.05s.88 2.38 1 2.54c.13.17 1.74 2.66 4.22 3.73.59.25 1.05.4 1.4.52.6.19 1.14.16 1.57.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.08.15-1.18-.06-.11-.22-.17-.47-.29Z" />
  </svg>
)
const IconPin = (p) => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
    <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
    <circle cx="12" cy="10" r="3" />
  </svg>
)

const SECTION_NAMES = ['Top', 'Services', 'The counter', 'How it works', 'Visit']

export default function Overlay({ progress = 0, onJump }) {
  const root = useReveal()
  const active = Math.min(4, Math.round(progress * 4))

  return (
    <div ref={root}>
      <header className="topbar">
        <a className="mark" href="#top">
          <b>Pratiksha Enterprises</b>
          <span>online seva kendra</span>
        </a>
        <nav className="nav-dots" aria-label="Sections">
          {SECTION_NAMES.map((n, i) => (
            <button
              key={n}
              type="button"
              title={n}
              aria-label={n}
              data-on={active === i}
              onClick={() => onJump?.(i)}
            />
          ))}
        </nav>
        <a className="btn btn-fill" href={`tel:${SHOP.phoneDial}`}>
          <IconPhone width="14" height="14" /> Call
        </a>
      </header>

      <div id="stage">
        {/* ── 1 ─────────────────────────────────────────────── */}
        <section className="stage-sec" id="top">
          <div className="stage-inner hero-in">
            <div className="hero-copy reveal on">
              <p className="eyebrow">Khade Bazaar · Belagavi · since {SHOP.since}</p>
              <h1>
                Pratiksha
                <em>Enterprises</em>
              </h1>
              <p className="hero-lede">
                Passport, PAN, PF, voter ID, ration card, scholarships, insurance, property
                records, printing and stationery. All at one counter.
              </p>
              <p className="hand">My father has sat at this counter since 2017.</p>
              <div className="hero-tags">
                <span>Passport</span><span>PAN</span><span>PF &amp; UAN</span><span>Voter ID</span>
                <span>Aadhaar</span><span>Insurance</span><span>e-Asti</span><span>Xerox</span>
              </div>
              <div className="cta-row">
                <a className="btn btn-fill" href={waHref} target="_blank" rel="noopener">
                  <IconWa width="15" height="15" /> WhatsApp the shop
                </a>
                <a className="btn btn-ghost" href="#index">See all 14 services</a>
              </div>
            </div>
          </div>
          <div className="scroll-hint" aria-hidden="true">
            <i /> scroll down
          </div>
        </section>

        {/* ── 2 ─────────────────────────────────────────────── */}
        <section className="stage-sec">
          <div className="stage-inner">
            <div className="sec-head reveal">
              <span className="count-badge">14</span>
              <p className="eyebrow">Everything handled here</p>
              <h2>Fourteen services</h2>
              <p>Government applications, insurance, document typing, printing and stationery.</p>
              <p className="hand" style={{ marginTop: 10 }}>hover the forms</p>
            </div>
          </div>
        </section>

        {/* ── 3 ─────────────────────────────────────────────── */}
        <section className="stage-sec">
          <div className="stage-inner">
            <div className="sec-head right bottom reveal">
              <p className="eyebrow">Inside the shop</p>
              <h2>The counter</h2>
              <p>Computer, printer, scanner and the files, all at one desk.</p>
            </div>
          </div>
        </section>

        {/* ── 4 ─────────────────────────────────────────────── */}
        <section className="stage-sec">
          <div className="stage-inner">
            <div className="sec-head reveal">
              <p className="eyebrow">How it works</p>
              <h2>Three steps</h2>
              <p>Forms are filled and checked here before they are submitted.</p>
            </div>
          </div>
        </section>

        {/* ── 5 ─────────────────────────────────────────────── */}
        <section className="stage-sec">
          <div className="stage-inner">
            <div className="sec-head bottom reveal">
              <p className="eyebrow">Visit</p>
              <h2>Vengurla Road, Khade Bazaar</h2>
              <p className="stage-addr">
                Pratiksha Enterprises, Vengurla Road,<br />
                Khade Bazaar, Belagavi (Belgaum) 590 001, Karnataka
              </p>
              <p>{SHOP.hours}. {SHOP.closed}.</p>
              <p className="hand" style={{ marginTop: 10 }}>walk in, no appointment</p>
            </div>
          </div>
        </section>
      </div>

      {/* ── the index ─────────────────────────────────────── */}
      <section className="sheet" id="index">
        <div className="sheet-in">
          <div className="index-head reveal">
            <h2>All services</h2>
            <p>
              What each service covers, and what to bring. Not sure which one you need? Ask on
              WhatsApp.
            </p>
          </div>

          <div className="index">
            {SERVICES.map((s) => (
              <article className="item" key={s.id}>
                <div className="item-top">
                  <span className="item-no">{s.no}</span>
                  <h3>{s.title}</h3>
                </div>
                <p className="item-sub">{s.sub}</p>
                <ul>
                  {s.lines.map((l) => (
                    <li key={l}>{l}</li>
                  ))}
                </ul>
                <p className="item-bring">
                  <b>Bring:</b> {s.bring}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ── steps in text, for anyone who scrolled past the 3d ─ */}
      <section className="sheet">
        <div className="sheet-in">
          <div className="index-head reveal">
            <h2>How a job runs</h2>
            <p>The same steps for every job.</p>
          </div>
          <div className="index" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))' }}>
            {STEPS.map((s) => (
              <article className="item" key={s.no}>
                <div className="item-top">
                  <span className="item-no">{s.no}</span>
                  <h3>{s.title}</h3>
                </div>
                <p style={{ color: 'var(--ink-2)', fontSize: 15.5 }}>{s.body}</p>
                <p className="item-bring">{s.note}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ── visit ─────────────────────────────────────────── */}
      <section className="sheet" id="visit">
        <div className="sheet-in visit">
          <div className="reveal">
            <p className="eyebrow">Visit the shop</p>
            <p className="addr">
              {SHOP.name}
              <br />
              {SHOP.street}
              <br />
              {SHOP.city}
            </p>
            <p className="addr-sub">
              {SHOP.state} · {SHOP.kannada}
            </p>

            <dl className="facts">
              <div><dt>Hours</dt><dd>{SHOP.hours}</dd></div>
              <div><dt>Sunday</dt><dd>Closed</dd></div>
              <div><dt>Phone</dt><dd>{SHOP.phoneDisplay}</dd></div>
              <div><dt>Legal name</dt><dd>M/s {SHOP.name}</dd></div>
              <div>
                <dt>Also listed on</dt>
                <dd><a href={SHOP.justdial} target="_blank" rel="noopener">Justdial</a></dd>
              </div>
            </dl>
          </div>

          <div className="reveal">
            <div className="reach">
              <a href={`tel:${SHOP.phoneDial}`}>
                <IconPhone />
                <span><b>{SHOP.phoneDisplay}</b><span>call the counter</span></span>
              </a>
              <a href={waHref} target="_blank" rel="noopener">
                <IconWa />
                <span><b>WhatsApp</b><span>send the file, collect the print</span></span>
              </a>
              <a href={SHOP.maps} target="_blank" rel="noopener">
                <IconPin />
                <span><b>Get directions</b><span>khade bazaar, belagavi</span></span>
              </a>
            </div>
            <p className="hand" style={{ marginTop: 22 }}>
              Send documents on WhatsApp and we will tell you what else is needed.
            </p>
          </div>
        </div>
      </section>

      {/* ── closing ───────────────────────────────────────── */}
      <section className="sheet closing">
        <div className="sheet-in closing-in">
          <div className="reveal">
            <h2>Ask before you come</h2>
            <p>
              Send the service you need on WhatsApp. We reply with the documents to bring and
               what it will cost.
            </p>
          </div>
          <div className="cta-row reveal">
            <a className="btn btn-fill" href={waHref} target="_blank" rel="noopener">
              <IconWa width="15" height="15" /> WhatsApp
            </a>
            <a className="btn" href={`tel:${SHOP.phoneDial}`}>Call the shop</a>
          </div>
        </div>
        <div className="foot">
          <div className="foot-in">
            <span>{SHOP.street}, {SHOP.city}, Karnataka</span>
            <span>{SHOP.phoneDisplay}</span>
            <span>© {new Date().getFullYear()} M/s {SHOP.name}</span>
          </div>
        </div>
      </section>
    </div>
  )
}
