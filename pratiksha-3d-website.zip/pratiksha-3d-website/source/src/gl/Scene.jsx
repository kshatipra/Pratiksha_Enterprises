import React, { Suspense } from 'react'
import { Canvas } from '@react-three/fiber'
import { Preload } from '@react-three/drei'
import World from './World.jsx'
import Rig from './Rig.jsx'

export default function Scene({ narrow, reduced, onProgress }) {
  // Protect the refresh rate: never render more than 2x, however many physical
  // pixels the display claims.
  const maxDpr = Math.min(typeof window !== 'undefined' ? window.devicePixelRatio : 1, 2)

  return (
    <Canvas
      className="webgl"
      dpr={[1, maxDpr]}
      gl={{
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
        stencil: false,
        depth: true,
      }}
      camera={{ fov: 42, near: 0.1, far: 140, position: [0, 0.55, 12] }}
      onCreated={({ gl }) => {
        gl.setClearAlpha(0)
      }}
    >
      <Suspense fallback={null}>
        <World narrow={narrow} reduced={reduced} />
        <Preload all />
      </Suspense>
      <Rig narrow={narrow} reduced={reduced} onProgress={onProgress} />
    </Canvas>
  )
}
