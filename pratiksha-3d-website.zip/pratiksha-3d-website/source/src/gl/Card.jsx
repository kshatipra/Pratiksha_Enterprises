import React, { useMemo, useRef, useState } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { makePencilMaterial } from './pencil.js'
import { Spring, Spring3 } from './spring.js'

/**
 * A sheet of paper.
 *
 * The geometry is genuinely curled on the CPU once at build time (and normals
 * recomputed), rather than faked in the vertex shader, so the pencil hatching
 * reacts to the curve the way it would on a real page.
 */
function curledPlane(w, h, seed = 0) {
  const g = new THREE.PlaneGeometry(w, h, 20, 20)
  const pos = g.attributes.position
  const curl = 0.055 + (seed % 7) * 0.006
  const twist = ((seed % 5) - 2) * 0.012
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i)
    const u = x / w, v = y / h
    const z =
      curl * w * (Math.cos(u * 2.3) - 0.82) +
      twist * w * u * v * 4 +
      Math.sin(v * 3.1 + seed) * 0.012 * h
    pos.setZ(i, z)
  }
  pos.needsUpdate = true
  g.computeVertexNormals()
  return g
}

export default function Card({
  texture,
  width = 1.5,
  height = 1.07,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  seed = 0,
  floatAmp = 0.06,
  floatSpeed = 0.5,
  interactive = true,
  reduced = false,
  onSelect,
  tint = '#ffffff',
}) {
  const group = useRef()
  const inner = useRef()
  const [hovered, setHovered] = useState(false)
  const local = useRef({ x: 0, y: 0 })

  const geo = useMemo(() => curledPlane(width, height, seed), [width, height, seed])
  const mat = useMemo(
    () =>
      makePencilMaterial({
        map: texture,
        tint,
        side: THREE.DoubleSide,
        rim: 0.42,
        density: 0.85,
        scale: 3.2,
        seed: seed * 1.7,
      }),
    [texture, seed, tint]
  )

  // one spring per degree of freedom the pointer can disturb
  const sp = useMemo(
    () => ({
      lift: new Spring(0, 120, 15),
      tilt: new Spring3(0, 0, 0, 70, 12),
      scale: new Spring(1, 140, 16),
    }),
    []
  )

  useFrame((state, dt) => {
    if (!group.current || !inner.current) return
    const t = state.clock.elapsedTime

    // idle drift — the page breathing on its own
    const drift = reduced ? 0 : floatAmp
    group.current.position.y =
      position[1] + Math.sin(t * floatSpeed + seed * 1.3) * drift
    group.current.position.x =
      position[0] + Math.cos(t * floatSpeed * 0.73 + seed) * drift * 0.5

    // pointer: a global lean plus, when hovered, a local tilt away from the cursor
    const px = state.pointer.x, py = state.pointer.y
    const lean = reduced ? 0 : 0.07
    const localTilt = hovered ? 0.3 : 0
    sp.tilt.set(
      rotation[0] + (-py * lean) + local.current.y * localTilt,
      rotation[1] + (px * lean) + local.current.x * localTilt,
      rotation[2] + Math.sin(t * 0.4 + seed) * (reduced ? 0 : 0.012)
    )
    sp.lift.set(hovered ? 0.42 : 0)
    sp.scale.set(hovered ? 1.07 : 1)

    sp.tilt.update(dt)
    sp.lift.update(dt)
    sp.scale.update(dt)

    sp.tilt.applyRotation(inner.current)
    inner.current.position.z = sp.lift.value
    const s = sp.scale.value
    inner.current.scale.set(s, s, s)
  })

  const over = (e) => {
    if (!interactive) return
    e.stopPropagation()
    setHovered(true)
    document.body.style.cursor = onSelect ? 'pointer' : 'default'
  }
  const out = (e) => {
    if (!interactive) return
    e.stopPropagation()
    setHovered(false)
    local.current.x = 0
    local.current.y = 0
    document.body.style.cursor = 'default'
  }
  const move = (e) => {
    if (!interactive || !e.uv) return
    // uv -> -1..1, inverted so the sheet tips away from the finger
    local.current.x = (e.uv.x - 0.5) * -2
    local.current.y = (e.uv.y - 0.5) * 2
  }

  return (
    <group ref={group} position={position}>
      <mesh
        ref={inner}
        geometry={geo}
        material={mat}
        onPointerOver={over}
        onPointerOut={out}
        onPointerMove={move}
        onClick={onSelect ? (e) => { e.stopPropagation(); onSelect() } : undefined}
      />
    </group>
  )
}
