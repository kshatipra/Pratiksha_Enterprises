import * as THREE from 'three'

/**
 * PencilMaterial — screen-space cross-hatching.
 *
 * Shading is quantised into four hatch passes whose line direction and spacing
 * are fixed in SCREEN space, not UV space, so the strokes stay a constant
 * thickness no matter how far the mesh is from the camera. That is what makes
 * geometry read as drawn-on-paper instead of textured.
 *
 * Every hatch coordinate is pushed around by value noise before it is wrapped,
 * which gives the lines a hand-held wobble; without it the result looks like a
 * halftone screen.
 */

export const PAPER = '#efe6d4'
export const INK = '#191410'
export const ORANGE = '#d4511c'
export const OCHRE = '#c98b24'
export const TEAL = '#1b7f8c'
export const BLUEINK = '#2d3a63'

// THREE.ColorManagement is on by default, so Color.set('#hex') already lands in
// the linear working space. Converting again here would darken everything.
const srgb = (hex) => new THREE.Color(hex)

const VERT = /* glsl */ `
  varying vec3 vWorldNormal;
  varying vec3 vViewDir;
  varying vec2 vUv;
  void main() {
    vUv = uv;
    vec4 wp = modelMatrix * vec4(position, 1.0);
    vWorldNormal = normalize(mat3(modelMatrix) * normal);
    vViewDir = normalize(cameraPosition - wp.xyz);
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`

const FRAG = /* glsl */ `
  uniform vec3  uPaper;
  uniform vec3  uInk;
  uniform vec3  uTint;
  uniform vec3  uLightDir;
  uniform float uScale;
  uniform float uRim;
  uniform float uDensity;
  uniform float uUseMap;
  uniform float uOpacity;
  uniform float uSeed;
  uniform sampler2D uMap;

  varying vec3 vWorldNormal;
  varying vec3 vViewDir;
  varying vec2 vUv;

  float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
  }
  float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
               mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
  }

  // one family of pencil strokes at a given angle
  float hatch(vec2 p, float angle, float spacing, float weight) {
    float s = sin(angle), c = cos(angle);
    float v = (p.x * c + p.y * s) / spacing;
    v += (vnoise(p * 0.030 + uSeed) - 0.5) * 1.10;   // long wobble
    v += (vnoise(p * 0.180 + uSeed) - 0.5) * 0.22;   // tooth of the paper
    float d = abs(fract(v) - 0.5);
    float line = 1.0 - smoothstep(weight * 0.5, weight * 0.5 + 0.20, d);
    line *= 0.72 + 0.28 * vnoise(p * 0.9 + uSeed * 3.0); // broken graphite
    return line;
  }

  void main() {
    vec2 sp = gl_FragCoord.xy / uScale;

    vec3 n = normalize(vWorldNormal);
    vec3 v = normalize(vViewDir);
    if (!gl_FrontFacing) n = -n;

    float lam = dot(n, normalize(uLightDir)) * 0.5 + 0.5;
    float fres = 1.0 - clamp(dot(n, v), 0.0, 1.0);
    lam -= pow(fres, 2.2) * uRim;                      // weight at the silhouette
    lam += (vnoise(sp * 0.55) - 0.5) * 0.09;           // graphite grain
    lam = clamp(lam, 0.0, 1.0);

    float ink = 0.0;
    if (lam < 0.90) ink = max(ink, hatch(sp,  0.80, 7.4, 0.30));
    if (lam < 0.66) ink = max(ink, hatch(sp, -0.60, 6.2, 0.34));
    if (lam < 0.44) ink = max(ink, hatch(sp,  1.78, 5.2, 0.38));
    if (lam < 0.22) ink = max(ink, hatch(sp,  0.14, 4.3, 0.44));
    ink *= smoothstep(0.95, 0.26, lam) * uDensity;

    vec3 base = uPaper * uTint;
    if (uUseMap > 0.5) {
      vec4 m = texture2D(uMap, vUv);
      base = mix(base, m.rgb, m.a);
    }

    vec3 col = mix(base, uInk, clamp(ink, 0.0, 1.0) * 0.86);
    gl_FragColor = vec4(col, uOpacity);
    #include <colorspace_fragment>
  }
`

export function makePencilMaterial(opts = {}) {
  const {
    paper = PAPER,
    ink = INK,
    tint = '#ffffff',
    map = null,
    rim = 0.55,
    density = 1.0,
    scale = 3.0,
    opacity = 1.0,
    side = THREE.FrontSide,
    transparent = false,
    seed = Math.random() * 10,
  } = opts

  return new THREE.ShaderMaterial({
    vertexShader: VERT,
    fragmentShader: FRAG,
    side,
    transparent,
    uniforms: {
      uPaper: { value: srgb(paper) },
      uInk: { value: srgb(ink) },
      uTint: { value: srgb(tint) },
      uLightDir: { value: new THREE.Vector3(-0.55, 0.78, 0.5).normalize() },
      uScale: { value: scale },
      uRim: { value: rim },
      uDensity: { value: density },
      uUseMap: { value: map ? 1 : 0 },
      uOpacity: { value: opacity },
      uSeed: { value: seed },
      uMap: { value: map },
    },
  })
}

/** Flat ink — used for the inverted-hull contour on solid objects. */
export function makeInkMaterial(color = INK) {
  return new THREE.MeshBasicMaterial({ color, side: THREE.BackSide })
}

export const ACCENTS = { ink: INK, orange: ORANGE, ochre: OCHRE, teal: TEAL, blue: BLUEINK }
