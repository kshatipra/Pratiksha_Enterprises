/**
 * Critically-dampable springs. Everything the pointer touches moves through one
 * of these instead of being assigned directly, so nothing in the scene ever
 * snaps — it accelerates, overshoots a little, and settles.
 */
export class Spring {
  constructor(value = 0, stiffness = 90, damping = 13) {
    this.value = value
    this.target = value
    this.velocity = 0
    this.k = stiffness
    this.c = damping
  }
  set(target) {
    this.target = target
    return this
  }
  jump(value) {
    this.value = this.target = value
    this.velocity = 0
    return this
  }
  update(dt) {
    // Fixed sub-steps: explicit integration goes unstable on a long frame, but
    // clamping dt instead would make the spring crawl on a slow device. This
    // keeps the motion identical at 144fps and at 20fps.
    let remaining = Math.min(dt, 0.25)
    const h = 1 / 120
    let guard = 0
    while (remaining > 0 && guard++ < 32) {
      const step = Math.min(h, remaining)
      const a = -this.k * (this.value - this.target) - this.c * this.velocity
      this.velocity += a * step
      this.value += this.velocity * step
      remaining -= step
    }
    return this.value
  }
}

export class Spring3 {
  constructor(x = 0, y = 0, z = 0, stiffness = 90, damping = 13) {
    this.x = new Spring(x, stiffness, damping)
    this.y = new Spring(y, stiffness, damping)
    this.z = new Spring(z, stiffness, damping)
  }
  set(x, y, z) {
    this.x.set(x); this.y.set(y); this.z.set(z)
    return this
  }
  update(dt) {
    this.x.update(dt); this.y.update(dt); this.z.update(dt)
    return this
  }
  applyPosition(obj) {
    obj.position.set(this.x.value, this.y.value, this.z.value)
  }
  applyRotation(obj) {
    obj.rotation.set(this.x.value, this.y.value, this.z.value)
  }
}

/**
 * Frame-rate independent exponential smoothing. Unconditionally stable for any
 * dt, so the cap only exists to stop a backgrounded tab from teleporting things
 * on its first frame back — it must stay generous or slow devices never arrive.
 */
export function damp(current, target, lambda, dt) {
  return current + (target - current) * (1 - Math.exp(-lambda * Math.min(dt, 0.1)))
}
