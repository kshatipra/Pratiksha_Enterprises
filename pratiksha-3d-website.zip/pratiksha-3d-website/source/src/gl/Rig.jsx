import { useEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'
import { useFrame, useThree } from '@react-three/fiber'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { damp } from './spring.js'

gsap.registerPlugin(ScrollTrigger)

/**
 * The camera does not jump between sections. GSAP scrubs a single parameter
 * along the page scroll; that parameter walks a Catmull-Rom path through the
 * five zones, and the result is damped again on the way to the camera, so even
 * a flung scroll arrives as a glide.
 */
const DESKTOP = {
  path: [
    [0.0, 0.55, 8.6],
    [-2.6, -12.3, 9.9],
    [2.4, -25.0, 8.7],
    [-2.0, -39.4, 8.9],
    [0.5, -52.4, 7.7],
  ],
  look: [
    [1.2, 0.1, 0],
    [0, -13.0, 0],
    [0, -26.2, 0],
    [0, -40.0, 0],
    [0, -52.9, 0],
  ],
}

const NARROW = {
  path: [
    [0.0, 0.3, 10.4],
    [-0.6, -12.6, 12.6],
    [0.8, -25.4, 11.4],
    [-0.4, -39.6, 11.2],
    [0.2, -52.6, 9.6],
  ],
  look: [
    [0, -1.1, 0],
    [0, -13.0, 0],
    [0, -26.0, 0],
    [0, -40.0, 0],
    [0, -52.9, 0],
  ],
}

export default function Rig({ narrow, reduced, onProgress }) {
  const { camera } = useThree()
  const proxy = useRef({ t: 0 })
  const intro = useRef({ pull: reduced ? 0 : 3.4 })
  const look = useRef(new THREE.Vector3())
  const px = useRef(0)
  const py = useRef(0)

  const { posCurve, lookCurve } = useMemo(() => {
    const src = narrow ? NARROW : DESKTOP
    const v = (a) => new THREE.Vector3(...a)
    return {
      posCurve: new THREE.CatmullRomCurve3(src.path.map(v), false, 'catmullrom', 0.4),
      lookCurve: new THREE.CatmullRomCurve3(src.look.map(v), false, 'catmullrom', 0.4),
    }
  }, [narrow])

  // scroll -> t
  useEffect(() => {
    const st = ScrollTrigger.create({
      // only the five scroll-linked sections drive the camera; the flat sheets
      // that follow leave it parked at the end of the path
      trigger: '#stage',
      start: 'top top',
      end: 'bottom bottom',
      scrub: reduced ? true : 1.0,
      onUpdate: (self) => {
        proxy.current.t = self.progress
        onProgress?.(self.progress)
      },
    })
    const id = setTimeout(() => ScrollTrigger.refresh(), 200)
    return () => {
      clearTimeout(id)
      st.kill()
    }
  }, [reduced, onProgress])

  // opening move: the camera settles into the page rather than starting there
  useEffect(() => {
    if (reduced) return
    const tw = gsap.to(intro.current, {
      pull: 0,
      duration: 2.1,
      ease: 'power3.out',
      delay: 0.15,
    })
    return () => tw.kill()
  }, [reduced])

  useFrame((state, dt) => {
    const t = THREE.MathUtils.clamp(proxy.current.t, 0, 1)
    const p = posCurve.getPoint(t)
    const l = lookCurve.getPoint(t)

    const lean = reduced ? 0 : 1
    px.current = damp(px.current, state.pointer.x, 2.6, dt)
    py.current = damp(py.current, state.pointer.y, 2.6, dt)

    camera.position.x = damp(camera.position.x, p.x + px.current * 0.52 * lean, 5.5, dt)
    camera.position.y = damp(camera.position.y, p.y + py.current * 0.32 * lean, 5.5, dt)
    camera.position.z = damp(camera.position.z, p.z + intro.current.pull, 5.5, dt)

    look.current.set(
      damp(look.current.x, l.x - px.current * 0.26 * lean, 4.2, dt),
      damp(look.current.y, l.y - py.current * 0.16 * lean, 4.2, dt),
      damp(look.current.z, l.z, 4.2, dt)
    )
    camera.lookAt(look.current)
  })

  return null
}
