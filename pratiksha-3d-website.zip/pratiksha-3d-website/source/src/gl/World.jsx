import React, { useMemo, useRef } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { Edges } from '@react-three/drei'
import Card from './Card.jsx'
import { makePencilMaterial, INK, ORANGE, OCHRE, TEAL, PAPER } from './pencil.js'
import { drawServiceCard, drawSignboard, drawStepSheet, drawBlankSheet, rng } from './textures.js'
import { SERVICES, STEPS } from '../data.js'

export const ZONE_Y = [0, -13, -26, -40, -53]

/* ── a solid object: pencil shading + a fine ink contour ───────────────── */
function Solid({ children, tint = '#ffffff', rim = 0.62, density = 1, edges = true, ...props }) {
  const mat = useMemo(
    () => makePencilMaterial({ tint, rim, density, scale: 3.0, seed: Math.random() * 10 }),
    [tint, rim, density]
  )
  return (
    <mesh material={mat} castShadow={false} {...props}>
      {children}
      {edges && <Edges threshold={22} color={INK} />}
    </mesh>
  )
}

/* ── zone 1 · the documents, adrift ────────────────────────────────────── */
function Hero({ narrow, reduced, textures }) {
  // The cluster lives in the right half of the frame on desktop so it never
  // fights the display type; on a phone it drops below the copy instead.
  const picks = narrow
    ? ['passport', 'pan', 'pf', 'aadhaar', 'vehicle']
    : ['passport', 'pan', 'pf', 'voter', 'aadhaar', 'vehicle', 'typing']
  const cx = narrow ? 0 : 4.2
  const cy = ZONE_Y[0] + (narrow ? -2.5 : 0)

  const layout = narrow
    ? [
        [-1.25, 0.9, -1.1, -0.16, 0.2],
        [1.2, 1.15, -1.6, 0.2, -0.16],
        [-1.05, -0.5, -0.3, -0.1, 0.14],
        [1.15, -0.75, -0.9, 0.14, -0.1],
        [0.05, 0.25, 0.3, 0.02, 0.0],
      ]
    : [
        [-1.85, 1.2, -1.6, -0.18, 0.26],
        [0.3, 1.75, -2.6, -0.1, 0.06],
        [1.9, 0.9, -1.1, 0.16, -0.22],
        [-1.35, -0.85, -0.3, -0.14, 0.18],
        [1.6, -1.2, -2.0, 0.2, -0.16],
        [0.1, -0.15, 0.55, 0.04, -0.02],
        [-0.25, -2.25, -1.5, 0.12, 0.1],
      ]

  return (
    <group position={[cx, cy, 0]}>
      {picks.map((id, i) => {
        const [x, y, z, rx, ry] = layout[i]
        const s = narrow ? 0.74 : 0.92
        return (
          <Card
            key={id}
            texture={textures[id]}
            width={1.62 * s}
            height={1.157 * s}
            position={[x, y, z]}
            rotation={[rx, ry, (i % 2 ? 1 : -1) * 0.04]}
            seed={i + 2}
            floatAmp={0.09}
            floatSpeed={0.42 + i * 0.045}
            reduced={reduced}
          />
        )
      })}
    </group>
  )
}

/* ── zone 2 · every service, as a wall of forms ────────────────────────── */
function Services({ narrow, reduced, textures }) {
  const rows = narrow ? [3, 3, 3, 3, 2] : [5, 4, 5]
  const s = narrow ? 0.6 : 0.8
  const cw = 1.62 * s, ch = 1.157 * s
  const gapX = cw * 1.22, gapY = ch * 1.45

  const placed = []
  let k = 0
  rows.forEach((n, r) => {
    for (let c = 0; c < n; c++) {
      const svc = SERVICES[k]
      if (!svc) return
      const x = (c - (n - 1) / 2) * gapX
      const y = ((rows.length - 1) / 2 - r) * gapY
      placed.push({ svc, x, y, z: -Math.abs(x) * 0.34 - Math.abs(y) * 0.12, i: k })
      k++
    }
  })

  return (
    // nudged right and down so the heading column on the left stays clear
    <group position={[narrow ? 0 : 2.3, ZONE_Y[1] - (narrow ? 1.3 : 1.0), 0]}>
      {placed.map(({ svc, x, y, z, i }) => (
        <Card
          key={svc.id}
          texture={textures[svc.id]}
          width={cw}
          height={ch}
          position={[x, y, z]}
          rotation={[y * 0.045, -x * 0.075, (i % 3 - 1) * 0.022]}
          seed={i + 11}
          floatAmp={0.035}
          floatSpeed={0.3 + (i % 5) * 0.05}
          reduced={reduced}
        />
      ))}
    </group>
  )
}

/* ── zone 3 · the counter ──────────────────────────────────────────────── */
function Counter({ narrow, reduced }) {
  const g = useRef()
  const screenTex = useMemo(() => drawBlankSheet(3, true), [])
  const screenMat = useMemo(
    () => makePencilMaterial({ map: screenTex, rim: 0.3, density: 0.6, scale: 3.0 }),
    [screenTex]
  )

  useFrame((state, dt) => {
    if (!g.current || reduced) return
    const t = state.clock.elapsedTime
    g.current.rotation.y = THREE.MathUtils.damp(
      g.current.rotation.y,
      state.pointer.x * 0.14 + Math.sin(t * 0.18) * 0.04,
      2.4,
      Math.min(dt, 1 / 30)
    )
  })

  const s = narrow ? 0.46 : 0.68
  const files = useMemo(() => {
    const r = rng(77)
    return new Array(9).fill(0).map((_, i) => ({
      x: -2.5 + i * 0.62 + (r() - 0.5) * 0.08,
      h: 0.42 + r() * 0.2,
      w: 0.17 + r() * 0.12,
      tilt: (r() - 0.5) * 0.28,
      tint: [PAPER, '#f3dcc6', '#e9e2cf'][i % 3],
    }))
  }, [])

  return (
    // sits left of centre; the section's copy is set hard right against it
    <group ref={g} position={[narrow ? 0 : -2.2, ZONE_Y[2] - (narrow ? 0.2 : 0.5), 0]} scale={s}>
      {/* desk */}
      <Solid position={[0, -0.14, 0]}>
        <boxGeometry args={[7.2, 0.26, 2.7]} />
      </Solid>
      <Solid position={[0, -1.05, 1.18]} rim={0.75}>
        <boxGeometry args={[7.2, 1.6, 0.14]} />
      </Solid>

      {/* monitor */}
      <Solid position={[-1.75, 0.18, -0.55]}>
        <boxGeometry args={[0.5, 0.38, 0.42]} />
      </Solid>
      <Solid position={[-1.75, 0.42, -0.55]}>
        <boxGeometry args={[0.16, 0.42, 0.16]} />
      </Solid>
      <group position={[-1.75, 1.28, -0.58]} rotation={[0, 0.16, 0]}>
        <Solid>
          <boxGeometry args={[2.1, 1.35, 0.13]} />
        </Solid>
        <mesh position={[0, 0, 0.075]} material={screenMat}>
          <planeGeometry args={[1.86, 1.14]} />
        </mesh>
      </group>

      {/* printer */}
      <group position={[2.0, 0.3, -0.45]} rotation={[0, -0.22, 0]}>
        <Solid>
          <boxGeometry args={[1.85, 0.92, 1.15]} />
        </Solid>
        <Solid position={[0, 0.56, 0.1]} rotation={[-0.22, 0, 0]}>
          <boxGeometry args={[1.45, 0.07, 0.72]} />
        </Solid>
        <Solid position={[0.0, 0.66, 0.42]} rotation={[-0.3, 0, 0.02]} tint="#ffffff">
          <boxGeometry args={[1.0, 0.02, 0.7]} />
        </Solid>
        <Solid position={[0.68, 0.18, 0.59]} rim={0.4}>
          <cylinderGeometry args={[0.07, 0.07, 0.04, 16]} />
        </Solid>
      </group>

      {/* paper stack, mug, pen stand */}
      <Solid position={[0.15, 0.05, 0.62]} rotation={[0, 0.1, 0]}>
        <boxGeometry args={[1.1, 0.16, 0.8]} />
      </Solid>
      <Solid position={[0.22, 0.17, 0.66]} rotation={[0, -0.07, 0]} tint="#ffffff">
        <boxGeometry args={[1.05, 0.08, 0.76]} />
      </Solid>
      <Solid position={[-0.62, 0.17, 0.95]} rim={0.5}>
        <cylinderGeometry args={[0.19, 0.16, 0.36, 20]} />
      </Solid>
      <Solid position={[0.95, 0.19, 0.92]} rim={0.5}>
        <cylinderGeometry args={[0.17, 0.15, 0.4, 18]} />
      </Solid>
      {[-0.06, 0.03, 0.1].map((o, i) => (
        <Solid
          key={i}
          position={[0.95 + o, 0.52, 0.92 + o * 0.6]}
          rotation={[0.1 * (i - 1), 0, 0.14 * (i - 1)]}
          tint={[ORANGE, TEAL, OCHRE][i]}
          rim={0.3}
          edges={false}
        >
          <cylinderGeometry args={[0.025, 0.025, 0.5, 8]} />
        </Solid>
      ))}

      {/* lamp */}
      <group position={[-3.05, 0.0, -0.3]}>
        <Solid position={[0, 0.02, 0]} rim={0.5}>
          <cylinderGeometry args={[0.28, 0.3, 0.08, 20]} />
        </Solid>
        <Solid position={[0.08, 0.72, 0]} rotation={[0, 0, -0.2]} rim={0.4}>
          <cylinderGeometry args={[0.04, 0.04, 1.4, 10]} />
        </Solid>
        <Solid position={[0.5, 1.46, 0]} rotation={[0, 0, -0.9]} tint={OCHRE} rim={0.5}>
          <coneGeometry args={[0.42, 0.52, 18, 1, true]} />
        </Solid>
      </group>

      {/* shelf of files behind the counter */}
      <Solid position={[0, 2.5, -1.75]}>
        <boxGeometry args={[6.4, 0.14, 0.62]} />
      </Solid>
      {files.map((f, i) => (
        <Solid
          key={i}
          position={[f.x, 2.57 + f.h / 2, -1.75]}
          rotation={[0, 0, f.tilt]}
          tint={f.tint}
          rim={0.5}
        >
          <boxGeometry args={[f.w, f.h, 0.5]} />
        </Solid>
      ))}

      {/* stool */}
      <group position={[-0.2, -1.55, 1.95]}>
        <Solid rim={0.5}>
          <cylinderGeometry args={[0.42, 0.42, 0.12, 20]} />
        </Solid>
        {[0, 1, 2].map((i) => {
          const a = (i / 3) * Math.PI * 2
          return (
            <Solid
              key={i}
              position={[Math.cos(a) * 0.3, -0.45, Math.sin(a) * 0.3]}
              rotation={[Math.sin(a) * 0.18, 0, -Math.cos(a) * 0.18]}
              rim={0.4}
            >
              <cylinderGeometry args={[0.04, 0.04, 0.9, 8]} />
            </Solid>
          )
        })}
      </group>

      {/* hanging bulb */}
      <group position={[3.95, 3.3, 0.4]}>
        <Solid position={[0, 0.9, 0]} rim={0.3} edges={false}>
          <cylinderGeometry args={[0.012, 0.012, 1.8, 6]} />
        </Solid>
        <Solid tint={OCHRE} rim={0.2}>
          <sphereGeometry args={[0.2, 18, 14]} />
        </Solid>
      </group>
    </group>
  )
}

/* ── zone 4 · three sheets pulled from a file ──────────────────────────── */
function Steps({ narrow, reduced, stepTex }) {
  const s = narrow ? 0.7 : 1
  return (
    <group position={[narrow ? 0 : 0.5, ZONE_Y[3] - (narrow ? 0.5 : 0.75), 0]}>
      {STEPS.map((st, i) => (
        <Card
          key={st.no}
          texture={stepTex[i]}
          width={1.9 * s}
          height={2.53 * s}
          position={narrow ? [0, (1 - i) * 2.9 * s, -i * 0.3] : [(i - 1) * 2.7 * s, 0, -Math.abs(i - 1) * 0.5]}
          rotation={[0, (1 - i) * 0.19, (i - 1) * 0.025]}
          seed={i + 31}
          floatAmp={0.05}
          floatSpeed={0.36 + i * 0.07}
          reduced={reduced}
        />
      ))}
    </group>
  )
}

/* ── zone 5 · the shop board ───────────────────────────────────────────── */
function Visit({ narrow, reduced, signTex }) {
  const s = narrow ? 0.62 : 1
  return (
    <group position={[narrow ? 0 : 1.25, ZONE_Y[4] + (narrow ? 0.4 : 0.85), 0]}>
      <Card
        texture={signTex}
        width={5.0 * s}
        height={2.5 * s}
        position={[0, 0.55 * s, 0]}
        rotation={[0.02, 0, -0.008]}
        seed={9}
        floatAmp={0.045}
        floatSpeed={0.3}
        reduced={reduced}
      />
      {/* two posts, as if the board is hung over the lane */}
      <Solid position={[-2.5 * s, -1.6 * s, -0.25]} rim={0.6}>
        <boxGeometry args={[0.13, 2.6 * s, 0.13]} />
      </Solid>
      <Solid position={[2.5 * s, -1.6 * s, -0.25]} rim={0.6}>
        <boxGeometry args={[0.13, 2.6 * s, 0.13]} />
      </Solid>
      <Solid position={[0, -2.95 * s, -0.25]} rim={0.6} tint={OCHRE}>
        <boxGeometry args={[5.3 * s, 0.12, 0.3]} />
      </Solid>
    </group>
  )
}

/* ── graphite specks drifting through the whole page ───────────────────── */
function Dust({ count = 160 }) {
  const ref = useRef()
  const { geo, mat } = useMemo(() => {
    const r = rng(5150)
    const positions = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (r() - 0.5) * 24
      positions[i * 3 + 1] = -r() * 58 + 4
      positions[i * 3 + 2] = (r() - 0.5) * 10 - 1
    }
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    const m = new THREE.PointsMaterial({
      color: INK,
      size: 0.035,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.4,
      depthWrite: false,
    })
    return { geo: g, mat: m }
  }, [count])

  useFrame((state) => {
    if (ref.current) {
      const t = state.clock.elapsedTime
      ref.current.rotation.y = Math.sin(t * 0.04) * 0.08
      ref.current.position.x = Math.sin(t * 0.07) * 0.3
    }
  })

  return <points ref={ref} geometry={geo} material={mat} frustumCulled={false} />
}

/* ── the whole page of paper ───────────────────────────────────────────── */
export default function World({ narrow, reduced }) {
  const textures = useMemo(() => {
    const out = {}
    SERVICES.forEach((s, i) => { out[s.id] = drawServiceCard(s, i) })
    return out
  }, [])
  const stepTex = useMemo(() => STEPS.map((s, i) => drawStepSheet(s, i)), [])
  const signTex = useMemo(() => drawSignboard(), [])

  return (
    <group>
      <Hero narrow={narrow} reduced={reduced} textures={textures} />
      <Services narrow={narrow} reduced={reduced} textures={textures} />
      <Counter narrow={narrow} reduced={reduced} />
      <Steps narrow={narrow} reduced={reduced} stepTex={stepTex} />
      <Visit narrow={narrow} reduced={reduced} signTex={signTex} />
      {!narrow && <Dust />}
    </group>
  )
}
