import * as THREE from 'three'
import { PAPER, INK, ACCENTS } from './pencil.js'

/* ── seeded randomness so a card looks identical on every reload ───────── */
export function rng(seed) {
  let a = seed >>> 0
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/* ── the pen ───────────────────────────────────────────────────────────── */

// A single wobbling stroke. Real pens overshoot and never travel straight.
function stroke(ctx, x1, y1, x2, y2, r, amp = 1.6, segs = 10) {
  const over = (r() - 0.5) * 6
  const dx = x2 - x1, dy = y2 - y1
  const len = Math.hypot(dx, dy) || 1
  const nx = -dy / len, ny = dx / len
  const ex = x2 + (dx / len) * over, ey = y2 + (dy / len) * over
  const sx = x1 - (dx / len) * over * 0.4, sy = y1 - (dy / len) * over * 0.4
  ctx.beginPath()
  ctx.moveTo(sx, sy)
  for (let i = 1; i <= segs; i++) {
    const t = i / segs
    const w = Math.sin(t * Math.PI) * amp * (r() - 0.5) * 2
    ctx.lineTo(sx + (ex - sx) * t + nx * w, sy + (ey - sy) * t + ny * w)
  }
  ctx.stroke()
}

// Two passes make a line read as pencil rather than vector.
function line(ctx, x1, y1, x2, y2, r, amp = 1.5) {
  stroke(ctx, x1, y1, x2, y2, r, amp)
  if (r() > 0.45) {
    ctx.save()
    ctx.globalAlpha *= 0.4
    stroke(ctx, x1 + (r() - 0.5) * 2, y1 + (r() - 0.5) * 2, x2 + (r() - 0.5) * 2, y2 + (r() - 0.5) * 2, r, amp * 1.3)
    ctx.restore()
  }
}

function box(ctx, x, y, w, h, r, amp = 1.5) {
  line(ctx, x, y, x + w, y, r, amp)
  line(ctx, x + w, y, x + w, y + h, r, amp)
  line(ctx, x + w, y + h, x, y + h, r, amp)
  line(ctx, x, y + h, x, y, r, amp)
}

function circle(ctx, cx, cy, rad, r, amp = 1.4) {
  ctx.beginPath()
  const segs = 36
  for (let i = 0; i <= segs; i++) {
    const a = (i / segs) * Math.PI * 2
    const rr = rad + (r() - 0.5) * amp * 2
    const px = cx + Math.cos(a) * rr, py = cy + Math.sin(a) * rr
    i ? ctx.lineTo(px, py) : ctx.moveTo(px, py)
  }
  ctx.closePath()
  ctx.stroke()
}

function hatch(ctx, x, y, w, h, r, angle = -0.7, gap = 7, alpha = 0.5) {
  ctx.save()
  ctx.globalAlpha *= alpha
  ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip()
  const diag = Math.hypot(w, h)
  const sx = Math.cos(angle), sy = Math.sin(angle)
  for (let d = -diag; d < diag; d += gap) {
    const mx = x + w / 2 + -sy * d, my = y + h / 2 + sx * d
    stroke(ctx, mx - sx * diag, my - sy * diag, mx + sx * diag, my + sy * diag, r, 1.1, 6)
  }
  ctx.restore()
}

// Squiggles standing in for body text — never fake-legible.
function textLines(ctx, x, y, w, count, r, gap = 13) {
  ctx.save()
  ctx.globalAlpha *= 0.55
  ctx.lineWidth = 2
  for (let i = 0; i < count; i++) {
    const ww = w * (0.55 + r() * 0.45)
    line(ctx, x, y + i * gap, x + ww, y + i * gap, r, 1.1)
  }
  ctx.restore()
}

/* ── motifs ────────────────────────────────────────────────────────────── */

const MOTIFS = {
  passport(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-0.1)
    box(ctx, -s * 0.34, -s * 0.46, s * 0.68, s * 0.92, r)
    line(ctx, -s * 0.26, -s * 0.46, -s * 0.26, s * 0.46, r)
    ctx.strokeStyle = acc
    circle(ctx, 0, -s * 0.1, s * 0.17, r)
    line(ctx, -s * 0.2, s * 0.22, s * 0.2, s * 0.22, r)
    line(ctx, -s * 0.14, s * 0.31, s * 0.14, s * 0.31, r)
    ctx.restore()
  },
  card(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(0.06)
    box(ctx, -s * 0.52, -s * 0.33, s * 1.04, s * 0.66, r)
    box(ctx, -s * 0.42, -s * 0.2, s * 0.3, s * 0.34, r)
    hatch(ctx, -s * 0.42, -s * 0.2, s * 0.3, s * 0.34, r, -0.8, 6, 0.4)
    ctx.strokeStyle = acc
    textLines(ctx, -s * 0.04, -s * 0.14, s * 0.46, 3, r, 11)
    ctx.restore()
  },
  gear(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy)
    ctx.strokeStyle = acc
    circle(ctx, 0, 0, s * 0.42, r)
    circle(ctx, 0, 0, s * 0.18, r)
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2
      line(ctx, Math.cos(a) * s * 0.42, Math.sin(a) * s * 0.42, Math.cos(a) * s * 0.55, Math.sin(a) * s * 0.55, r, 1)
    }
    ctx.restore()
  },
  idcard(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-0.05)
    box(ctx, -s * 0.5, -s * 0.34, s, s * 0.68, r)
    line(ctx, -s * 0.5, -s * 0.18, s * 0.5, -s * 0.18, r)
    circle(ctx, -s * 0.28, s * 0.06, s * 0.13, r)
    ctx.strokeStyle = acc
    textLines(ctx, -s * 0.08, -s * 0.02, s * 0.5, 3, r, 11)
    ctx.restore()
  },
  doc(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(0.04)
    box(ctx, -s * 0.36, -s * 0.5, s * 0.72, s, r)
    ctx.strokeStyle = acc
    line(ctx, -s * 0.24, -s * 0.3, s * 0.24, -s * 0.3, r)
    ctx.strokeStyle = INK
    textLines(ctx, -s * 0.24, -s * 0.12, s * 0.48, 5, r, 12)
    ctx.restore()
  },
  sheaf(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy)
    for (let i = 2; i >= 0; i--) {
      ctx.save(); ctx.translate(i * s * 0.1 - s * 0.1, i * s * 0.08 - s * 0.08); ctx.rotate((i - 1) * 0.07)
      ctx.strokeStyle = i === 0 ? acc : INK
      box(ctx, -s * 0.34, -s * 0.44, s * 0.68, s * 0.88, r)
      ctx.restore()
    }
    ctx.strokeStyle = INK
    textLines(ctx, -s * 0.24, -s * 0.2, s * 0.44, 4, r, 12)
    ctx.restore()
  },
  ribbon(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy - s * 0.12)
    ctx.strokeStyle = acc
    circle(ctx, 0, 0, s * 0.3, r)
    circle(ctx, 0, 0, s * 0.19, r)
    ctx.strokeStyle = INK
    line(ctx, -s * 0.18, s * 0.26, -s * 0.3, s * 0.66, r)
    line(ctx, -s * 0.3, s * 0.66, -s * 0.08, s * 0.54, r)
    line(ctx, s * 0.18, s * 0.26, s * 0.3, s * 0.66, r)
    line(ctx, s * 0.3, s * 0.66, s * 0.08, s * 0.54, r)
    ctx.restore()
  },
  car(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy)
    ctx.strokeStyle = acc
    line(ctx, -s * 0.56, s * 0.14, -s * 0.4, s * 0.14, r)
    line(ctx, -s * 0.4, s * 0.14, -s * 0.26, -s * 0.16, r)
    line(ctx, -s * 0.26, -s * 0.16, s * 0.18, -s * 0.16, r)
    line(ctx, s * 0.18, -s * 0.16, s * 0.4, s * 0.14, r)
    line(ctx, s * 0.4, s * 0.14, s * 0.56, s * 0.14, r)
    line(ctx, -s * 0.56, s * 0.14, s * 0.56, s * 0.14, r)
    ctx.strokeStyle = INK
    circle(ctx, -s * 0.3, s * 0.2, s * 0.12, r)
    circle(ctx, s * 0.3, s * 0.2, s * 0.12, r)
    line(ctx, -s * 0.2, -s * 0.14, -s * 0.2, -s * 0.02, r)
    ctx.restore()
  },
  umbrella(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy - s * 0.06)
    ctx.strokeStyle = acc
    ctx.beginPath()
    for (let i = 0; i <= 28; i++) {
      const t = i / 28, a = Math.PI + t * Math.PI
      const px = Math.cos(a) * s * 0.52, py = Math.sin(a) * s * 0.42 + (r() - 0.5) * 2
      i ? ctx.lineTo(px, py) : ctx.moveTo(px, py)
    }
    ctx.stroke()
    line(ctx, -s * 0.52, 0, s * 0.52, 0, r)
    ctx.strokeStyle = INK
    for (const o of [-0.26, 0, 0.26]) line(ctx, o * s, 0, o * s * 0.52, -s * 0.38, r, 1)
    line(ctx, 0, 0, 0, s * 0.46, r)
    line(ctx, 0, s * 0.46, s * 0.14, s * 0.52, r)
    ctx.restore()
  },
  photo(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy)
    for (let i = 0; i < 4; i++) {
      const gx = (i % 2) * s * 0.5 - s * 0.5, gy = Math.floor(i / 2) * s * 0.55 - s * 0.55
      ctx.strokeStyle = i === 0 ? acc : INK
      box(ctx, gx + s * 0.04, gy + s * 0.04, s * 0.42, s * 0.47, r, 1.2)
      circle(ctx, gx + s * 0.25, gy + s * 0.2, s * 0.09, r, 1.1)
      ctx.beginPath()
      ctx.moveTo(gx + s * 0.1, gy + s * 0.5)
      ctx.quadraticCurveTo(gx + s * 0.25, gy + s * 0.3, gx + s * 0.4, gy + s * 0.5)
      ctx.stroke()
    }
    ctx.restore()
  },
  typewriter(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy)
    box(ctx, -s * 0.46, -s * 0.04, s * 0.92, s * 0.42, r)
    ctx.strokeStyle = acc
    box(ctx, -s * 0.3, -s * 0.56, s * 0.6, s * 0.52, r)
    ctx.strokeStyle = INK
    textLines(ctx, -s * 0.22, -s * 0.42, s * 0.44, 3, r, 10)
    for (let i = 0; i < 4; i++) line(ctx, -s * 0.36 + i * s * 0.2, s * 0.1, -s * 0.28 + i * s * 0.2, s * 0.1, r, 1)
    line(ctx, -s * 0.3, s * 0.26, s * 0.3, s * 0.26, r)
    ctx.restore()
  },
  house(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy)
    ctx.strokeStyle = acc
    line(ctx, -s * 0.52, -s * 0.04, 0, -s * 0.48, r)
    line(ctx, 0, -s * 0.48, s * 0.52, -s * 0.04, r)
    ctx.strokeStyle = INK
    box(ctx, -s * 0.4, -s * 0.04, s * 0.8, s * 0.52, r)
    box(ctx, -s * 0.12, s * 0.14, s * 0.24, s * 0.34, r, 1.2)
    box(ctx, s * 0.16, s * 0.04, s * 0.16, s * 0.16, r, 1.2)
    hatch(ctx, -s * 0.36, s * 0.02, s * 0.2, s * 0.2, r, -0.8, 6, 0.4)
    ctx.restore()
  },
  printer(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy)
    box(ctx, -s * 0.48, -s * 0.1, s * 0.96, s * 0.44, r)
    ctx.strokeStyle = acc
    box(ctx, -s * 0.3, -s * 0.52, s * 0.6, s * 0.42, r)
    textLines(ctx, -s * 0.22, -s * 0.4, s * 0.44, 3, r, 10)
    ctx.strokeStyle = INK
    box(ctx, -s * 0.26, s * 0.34, s * 0.52, s * 0.16, r, 1.2)
    circle(ctx, s * 0.3, s * 0.04, s * 0.05, r, 1)
    ctx.restore()
  },
  pens(ctx, cx, cy, s, r, acc) {
    ctx.save(); ctx.translate(cx, cy)
    box(ctx, -s * 0.3, s * 0.02, s * 0.6, s * 0.46, r)
    hatch(ctx, -s * 0.3, s * 0.02, s * 0.6, s * 0.46, r, -0.9, 8, 0.35)
    const cols = [acc, INK, acc]
    for (let i = 0; i < 3; i++) {
      ctx.strokeStyle = cols[i]
      const ox = -s * 0.2 + i * s * 0.2, h = s * (0.44 + i * 0.07)
      line(ctx, ox, s * 0.04, ox + (i - 1) * s * 0.06, s * 0.04 - h, r, 1.2)
      line(ctx, ox + s * 0.08, s * 0.04, ox + s * 0.08 + (i - 1) * s * 0.06, s * 0.04 - h, r, 1.2)
      line(ctx, ox + (i - 1) * s * 0.06, s * 0.04 - h, ox + s * 0.08 + (i - 1) * s * 0.06, s * 0.04 - h, r, 1.2)
    }
    ctx.restore()
  },
}

/* ── the service card face ─────────────────────────────────────────────── */

export function drawServiceCard(svc, i) {
  const W = 420, H = 300
  const cv = document.createElement('canvas')
  cv.width = W; cv.height = H
  const ctx = cv.getContext('2d')
  const r = rng(i * 7919 + 13)
  const acc = ACCENTS[svc.accent] || ACCENTS.ink

  ctx.fillStyle = PAPER
  ctx.fillRect(0, 0, W, H)

  // paper tooth
  ctx.save()
  for (let k = 0; k < 900; k++) {
    ctx.globalAlpha = r() * 0.05
    ctx.fillStyle = r() > 0.5 ? '#000' : '#fff'
    ctx.fillRect(r() * W, r() * H, 1.4, 1.4)
  }
  ctx.restore()

  ctx.lineCap = 'round'
  ctx.lineJoin = 'round'
  ctx.strokeStyle = INK
  ctx.lineWidth = 2.6

  // double ruled border, the way a form is boxed
  box(ctx, 14, 14, W - 28, H - 28, r, 2)
  ctx.save(); ctx.globalAlpha = 0.35
  box(ctx, 20, 20, W - 40, H - 40, r, 1.6)
  ctx.restore()

  // header rule + serial
  ctx.lineWidth = 2.2
  line(ctx, 34, 74, W - 34, 74, r, 1.4)

  ctx.font = '700 20px Kalam, cursive'
  ctx.fillStyle = acc
  ctx.fillText(svc.no, 34, 58)

  ctx.font = '800 30px Syne, Impact, sans-serif'
  ctx.fillStyle = INK
  const title = svc.title.toUpperCase()
  ctx.save()
  ctx.translate(72, 59)
  ctx.rotate(-0.012)
  ctx.fillText(title, 0, 0)
  ctx.restore()

  ctx.font = '400 17px Kalam, cursive'
  ctx.fillStyle = acc
  ctx.fillText(svc.sub, 36, 100)

  // motif on the right, squiggles on the left — same anatomy on all 14 cards
  const motif = MOTIFS[svc.kind] || MOTIFS.doc
  ctx.lineWidth = 2.6
  ctx.strokeStyle = INK
  motif(ctx, W - 108, 190, 86, r, acc)

  ctx.strokeStyle = INK
  ctx.lineWidth = 2
  textLines(ctx, 36, 134, 200, 5, r, 17)

  // corner tick, like a checked form
  ctx.strokeStyle = acc
  ctx.lineWidth = 3
  line(ctx, 34, H - 44, 48, H - 32, r, 1)
  line(ctx, 48, H - 32, 74, H - 62, r, 1)

  const tex = new THREE.CanvasTexture(cv)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.anisotropy = 4
  return tex
}

/* ── the hero title plate ──────────────────────────────────────────────── */

export function drawSignboard() {
  const W = 1024, H = 512
  const cv = document.createElement('canvas')
  cv.width = W; cv.height = H
  const ctx = cv.getContext('2d')
  const r = rng(4242)

  ctx.fillStyle = PAPER
  ctx.fillRect(0, 0, W, H)
  ctx.save()
  for (let k = 0; k < 2600; k++) {
    ctx.globalAlpha = r() * 0.05
    ctx.fillStyle = r() > 0.5 ? '#000' : '#fff'
    ctx.fillRect(r() * W, r() * H, 1.6, 1.6)
  }
  ctx.restore()

  ctx.lineCap = 'round'; ctx.lineJoin = 'round'
  ctx.strokeStyle = INK; ctx.lineWidth = 5
  box(ctx, 26, 26, W - 52, H - 52, r, 3)
  ctx.lineWidth = 2.5
  ctx.save(); ctx.globalAlpha = 0.4
  box(ctx, 40, 40, W - 80, H - 80, r, 2)
  ctx.restore()

  ctx.textAlign = 'center'
  ctx.fillStyle = INK
  ctx.font = '800 92px Syne, Impact, sans-serif'
  ctx.save(); ctx.translate(W / 2, 182); ctx.rotate(-0.008)
  ctx.fillText('PRATIKSHA', 0, 0)
  ctx.restore()
  ctx.save(); ctx.translate(W / 2, 278); ctx.rotate(0.006)
  ctx.fillText('ENTERPRISES', 0, 0)
  ctx.restore()

  ctx.strokeStyle = ACCENTS.orange; ctx.lineWidth = 6
  line(ctx, W / 2 - 190, 316, W / 2 + 190, 316, r, 2)

  ctx.fillStyle = ACCENTS.orange
  ctx.font = '700 38px Kalam, cursive'
  ctx.fillText('Online Seva Kendra', W / 2, 372)

  ctx.fillStyle = INK
  ctx.font = '400 28px Kalam, cursive'
  ctx.fillText('Khade Bazaar  ·  Belagavi', W / 2, 426)

  const tex = new THREE.CanvasTexture(cv)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.anisotropy = 4
  return tex
}

/* ── a plain sheet with a hand-drawn number, for the three steps ───────── */

export function drawStepSheet(step, i) {
  const W = 360, H = 480
  const cv = document.createElement('canvas')
  cv.width = W; cv.height = H
  const ctx = cv.getContext('2d')
  const r = rng(i * 331 + 7)

  ctx.fillStyle = PAPER
  ctx.fillRect(0, 0, W, H)
  ctx.save()
  for (let k = 0; k < 800; k++) {
    ctx.globalAlpha = r() * 0.05
    ctx.fillStyle = r() > 0.5 ? '#000' : '#fff'
    ctx.fillRect(r() * W, r() * H, 1.4, 1.4)
  }
  ctx.restore()

  ctx.lineCap = 'round'; ctx.lineJoin = 'round'
  ctx.strokeStyle = INK; ctx.lineWidth = 2.4
  box(ctx, 16, 16, W - 32, H - 32, r, 2)

  // punch holes down the left edge — a sheet pulled out of a file
  for (let k = 0; k < 3; k++) circle(ctx, 40, 120 + k * 120, 9, r, 1)

  ctx.strokeStyle = ACCENTS.orange
  ctx.lineWidth = 7
  ctx.font = '800 150px Syne, Impact, sans-serif'
  ctx.fillStyle = ACCENTS.orange
  ctx.save(); ctx.translate(86, 190); ctx.rotate(-0.03)
  ctx.fillText(step.no, 0, 0)
  ctx.restore()

  ctx.strokeStyle = INK; ctx.lineWidth = 2.4
  line(ctx, 80, 220, W - 40, 220, r, 1.6)
  textLines(ctx, 80, 258, 210, 7, r, 19)

  ctx.fillStyle = ACCENTS.teal
  ctx.font = '400 21px Kalam, cursive'
  ctx.fillText(step.note, 80, H - 54)

  const tex = new THREE.CanvasTexture(cv)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.anisotropy = 4
  return tex
}

/* ── blank paper, for stacks and props ─────────────────────────────────── */

export function drawBlankSheet(seed = 1, withText = true) {
  const W = 256, H = 340
  const cv = document.createElement('canvas')
  cv.width = W; cv.height = H
  const ctx = cv.getContext('2d')
  const r = rng(seed * 991)
  ctx.fillStyle = PAPER
  ctx.fillRect(0, 0, W, H)
  ctx.lineCap = 'round'
  ctx.strokeStyle = INK
  ctx.lineWidth = 2
  box(ctx, 10, 10, W - 20, H - 20, r, 1.6)
  if (withText) {
    textLines(ctx, 28, 54, 190, 9, r, 24)
    ctx.strokeStyle = ACCENTS.orange
    line(ctx, 28, 30, 120, 30, r, 1.4)
  }
  const tex = new THREE.CanvasTexture(cv)
  tex.colorSpace = THREE.SRGBColorSpace
  return tex
}

export { line as penLine, box as penBox, circle as penCircle, hatch as penHatch }
