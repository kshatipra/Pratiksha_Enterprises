import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { viteSingleFile } from 'vite-plugin-singlefile'

// `npm run build`          -> normal multi-file build in dist/      (upload to any host)
// `SINGLE=1 npm run build` -> one self-contained index.html in dist/ (drag-and-drop anywhere)
const single = process.env.SINGLE === '1'

export default defineConfig({
  plugins: [react(), ...(single ? [viteSingleFile()] : [])],
  base: './',
  build: {
    target: 'es2020',
    assetsInlineLimit: single ? 100000000 : 4096,
    cssCodeSplit: !single,
    chunkSizeWarningLimit: 2000,
    rollupOptions: single ? { output: { inlineDynamicImports: true } } : {},
  },
})
